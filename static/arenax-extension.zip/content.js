// ArenaX 에이전트 하단 바 (content script v5)
// - 활성 임무(실행중/중단됨) 최대 5개, 기록(완료/오류 등)은 별도 섹션
// - 임무 목록 높이를 드래그로 조절 가능
// - 최신 임무가 아래에 표시 (push 순서)
// - 런처 말풍선: 3초 + X닫기
(() => {
  if (window.__arenaxAgentInjected) return;
  window.__arenaxAgentInjected = true;

  const host = document.createElement("div");
  host.id = "__arenax_agent_host";
  Object.assign(host.style, {
    position: "fixed", left: "0", right: "0", bottom: "0",
    width: "100%", zIndex: "2147483647", pointerEvents: "none",
  });
  const shadow = host.attachShadow({ mode: "open" });

  const CSS = `
  :host { all: initial; }
  * { box-sizing: border-box; font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", "Malgun Gothic", sans-serif; }

  .launcher {
    pointer-events: auto; position: fixed; right: 16px;
    width: 52px; height: 52px; border-radius: 50%; border: 0; cursor: grab;
    background: #7c3aed; color: #fff; font-size: 22px; line-height: 1;
    box-shadow: 0 6px 20px rgba(124,58,237,.45);
    display: none; touch-action: none; user-select: none; z-index: 1;
  }
  .launcher.show { display: flex; align-items: center; justify-content: center; }
  .launcher:active { cursor: grabbing; }
  .launcher:hover { background: #6d28d9; }

  .bubble {
    --bg: #1f2937;
    pointer-events: auto; position: fixed; right: 76px;
    background: var(--bg); color: #fff;
    padding: 7px 10px 7px 13px; border-radius: 10px;
    font-size: 12px; font-weight: 600; max-width: 240px;
    display: none; align-items: center; gap: 6px;
    box-shadow: 0 4px 14px rgba(0,0,0,.3); z-index: 1;
  }
  .bubble.show { display: flex; }
  .bubble-text { flex: 1 1 auto; min-width: 0; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
  .bubble-close { flex: 0 0 auto; background: transparent; border: 0; color: rgba(255,255,255,.75); cursor: pointer; font-size: 13px; line-height: 1; padding: 0; }
  .bubble-close:hover { color: #fff; }
  .bubble::after {
    content: ''; position: absolute; right: -7px; top: 50%; transform: translateY(-50%);
    border: 7px solid transparent; border-left-color: var(--bg); border-right-width: 0;
  }
  .bubble.success  { --bg: #065f46; }
  .bubble.error    { --bg: #7f1d1d; }
  .bubble.handoff  { --bg: #78350f; }
  .bubble.cancelled { --bg: #374151; }

  .wrap { pointer-events: none; display: flex; flex-direction: column; align-items: center; padding: 0 12px 12px; }
  .bar {
    pointer-events: auto; width: 100%; max-width: 940px;
    background: #fff; color: #111827;
    border: 1px solid #e5e7eb; border-radius: 16px 16px 12px 12px;
    box-shadow: 0 -6px 30px rgba(0,0,0,.18);
    display: flex; flex-direction: column; overflow: hidden;
  }
  .bar[hidden] { display: none; }

  /* ── 모바일 (≤ 640px) : 풀스크린 바텀시트 스타일 ── */
  @media (max-width: 640px) {
    .wrap { padding: 0; }
    .bar {
      max-width: 100%; border-radius: 16px 16px 0 0;
      max-height: 90dvh; max-height: 90vh;
    }
    .launcher { width: 48px; height: 48px; font-size: 20px; right: 12px; }
    .bubble { max-width: 180px; font-size: 11px; right: 68px; }
    /* iOS 폼 요소 줌 방지 (font-size < 16px → iOS 자동 줌) */
    .task-input { font-size: 16px !important; }
    .settings input { font-size: 16px !important; }
    /* 버튼 터치 영역 확장 */
    .tbtn { padding: 5px 11px; font-size: 12px; min-height: 30px; }
    .send-btn { min-width: 56px; font-size: 15px; }
    .icon-btn, .end-btn { padding: 6px 10px; font-size: 12px; min-height: 32px; }
    .min-btn { padding: 7px 14px; font-size: 14px; min-width: 60px; }
    /* 리사이즈 핸들 터치 영역 확장 */
    .resize-handle { height: 10px; }
    .resize-handle::before { height: 4px; width: 40px; }
    /* 태스크 높이 기본값을 모바일에 맞게 제한 */
    .tasks-wrap { max-height: 45vh; }
  }

  .head { display: flex; align-items: center; gap: 8px; padding: 10px 14px; border-bottom: 1px solid #f1f1f4; background: #faf5ff; flex-shrink: 0; }
  .title { font-size: 14px; font-weight: 800; color: #6d28d9; flex: 0 0 auto; }
  .task-counter { flex: 1 1 auto; font-size: 11px; font-weight: 700; color: #7c3aed; background: #ede9fe; border-radius: 20px; padding: 2px 9px; white-space: nowrap; display: inline-block; align-self: center; }
  .task-counter.full { background: #fecaca; color: #b91c1c; }
  .head-btns { display: flex; gap: 6px; flex: 0 0 auto; align-items: center; }
  .icon-btn { border: 1px solid #e5e7eb; background: #fff; border-radius: 8px; cursor: pointer; font-size: 12px; padding: 5px 11px; color: #6b7280; white-space: nowrap; }
  .icon-btn:hover { background: #f3f4f6; }
  /* 접기 버튼 — 눈에 띄게 크게 */
  .min-btn {
    border: 2px solid #c4b5fd; background: #ede9fe; color: #7c3aed;
    border-radius: 8px; cursor: pointer; font-size: 15px; font-weight: 900;
    padding: 6px 18px; white-space: nowrap; line-height: 1;
    min-width: 72px; text-align: center;
  }
  .min-btn:hover { background: #ddd6fe; border-color: #a78bfa; }
  .end-btn { border: 1px solid #fecaca; background: #fef2f2; color: #b91c1c; border-radius: 8px; cursor: pointer; font-size: 12px; font-weight: 700; padding: 5px 12px; white-space: nowrap; }
  .end-btn:hover { background: #fee2e2; }

  .settings { display: none; padding: 8px 14px; border-bottom: 1px solid #f1f1f4; gap: 6px; flex-shrink: 0; }
  .settings.open { display: flex; }
  .settings input { flex: 1; padding: 6px 10px; border: 1px solid #d1d5db; border-radius: 8px; font-size: 12px; }
  .settings button { padding: 6px 12px; border: 0; background: #7c3aed; color: #fff; border-radius: 8px; font-size: 12px; font-weight: 700; cursor: pointer; }

  /* 높이 조절 핸들 */
  .resize-handle {
    pointer-events: auto; flex-shrink: 0;
    height: 6px; background: #f1f1f4; cursor: ns-resize;
    border-top: 1px solid #e5e7eb; border-bottom: 1px solid #e5e7eb;
    display: flex; align-items: center; justify-content: center;
  }
  .resize-handle::before { content: ''; width: 32px; height: 3px; border-radius: 2px; background: #d1d5db; }
  .resize-handle:hover, .resize-handle:hover::before { background: #c4b5fd; }

  /* 임무 영역 */
  .tasks-wrap { overflow-y: auto; flex-shrink: 0; }
  .tasks-inner { display: flex; flex-direction: column; gap: 6px; padding: 10px 14px; }
  .section-label { font-size: 11px; font-weight: 700; color: #9ca3af; text-transform: uppercase; letter-spacing: 0.05em; padding: 4px 0 2px; }
  .empty { font-size: 13px; color: #9ca3af; padding: 2px 0; }

  /* 임무 카드 */
  .task-card { border: 1px solid #e5e7eb; border-radius: 10px; overflow: hidden; background: #fff; }
  .task-card[data-status="running"]   { border-left: 3px solid #3b82f6; }
  .task-card[data-status="paused"]    { border-left: 3px solid #f59e0b; }
  .task-card[data-status="success"]   { border-left: 3px solid #10b981; }
  .task-card[data-status="error"]     { border-left: 3px solid #ef4444; }
  .task-card[data-status="handoff"]   { border-left: 3px solid #f59e0b; }
  .task-card[data-status="cancelled"] { border-left: 3px solid #9ca3af; }
  .task-card.archived { opacity: 0.8; }

  .task-head { display: flex; align-items: center; gap: 6px; padding: 7px 10px 3px; }
  .task-text { flex: 1 1 auto; font-size: 13px; font-weight: 700; color: #111827; min-width: 0; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
  .task-badge { flex: 0 0 auto; font-size: 11px; font-weight: 700; padding: 2px 8px; border-radius: 20px; white-space: nowrap; }
  .task-badge.running   { background: #dbeafe; color: #1d4ed8; }
  .task-badge.paused    { background: #fef3c7; color: #b45309; }
  .task-badge.success   { background: #d1fae5; color: #065f46; }
  .task-badge.error     { background: #fee2e2; color: #b91c1c; }
  .task-badge.handoff   { background: #fef3c7; color: #b45309; }
  .task-badge.cancelled { background: #f3f4f6; color: #6b7280; }

  .task-latest { font-size: 12px; color: #4b5563; padding: 0 10px 2px; overflow-wrap: anywhere; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
  .task-result { font-size: 12px; font-weight: 600; padding: 2px 10px 5px; overflow-wrap: anywhere; white-space: pre-wrap; }
  .task-result.success   { color: #047857; }
  .task-result.error     { color: #b91c1c; }
  .task-result.handoff   { color: #b45309; }
  .task-result.cancelled { color: #6b7280; }

  .task-btns { display: flex; flex-wrap: wrap; gap: 5px; padding: 3px 10px 7px; align-items: center; }
  .tbtn { border: 1px solid #e5e7eb; background: #f9fafb; border-radius: 6px; cursor: pointer; font-size: 11px; font-weight: 700; padding: 3px 9px; white-space: nowrap; }
  .tbtn:hover { filter: brightness(.93); }
  .tbtn.pause-btn   { border-color: #fbbf24; color: #b45309; }
  .tbtn.resume-btn  { border-color: #34d399; background: #ecfdf5; color: #065f46; }
  .tbtn.cancel-btn  { border-color: #fca5a5; color: #b91c1c; }
  .tbtn.edit-btn    { border-color: #93c5fd; color: #1d4ed8; }
  .tbtn.delete-btn  { margin-left: auto; border-color: #d1d5db; color: #9ca3af; }

  .confirm { display: none; padding: 10px 14px; border-top: 1px solid #f1f1f4; background: #fffbeb; flex-direction: column; gap: 8px; flex-shrink: 0; }
  .confirm.open { display: flex; }
  .confirm-msg { font-size: 13px; color: #92400e; line-height: 1.5; white-space: pre-wrap; }
  .confirm-btns { display: flex; gap: 8px; }
  .confirm-btns button { flex: 1; padding: 8px; border: 0; border-radius: 8px; font-size: 13px; font-weight: 700; cursor: pointer; }
  .approve-btn { background: #16a34a; color: #fff; }
  .reject-btn  { background: #e5e7eb; color: #374151; }

  .input-row { display: flex; gap: 8px; padding: 10px 14px; border-top: 1px solid #f1f1f4; align-items: flex-end; flex-shrink: 0; }
  .task-input {
    flex: 1; resize: none; overflow: hidden; min-height: 40px; max-height: 120px;
    padding: 10px 12px; border: 1px solid #d1d5db; border-radius: 10px;
    font-size: 14px; line-height: 1.5; color: #111827; background: #fff;
  }
  .task-input:focus { outline: none; border-color: #7c3aed; box-shadow: 0 0 0 3px rgba(124,58,237,.15); }
  .task-input.full { border-color: #fca5a5; }
  .send-btn { align-self: stretch; min-width: 64px; border: 0; border-radius: 10px; background: #7c3aed; color: #fff; font-size: 14px; font-weight: 800; cursor: pointer; }
  .send-btn:hover:not(:disabled) { background: #6d28d9; }
  .send-btn:disabled { background: #c4b5fd; cursor: not-allowed; }
  `;

  try {
    const sheet = new CSSStyleSheet();
    sheet.replaceSync(CSS);
    shadow.adoptedStyleSheets = [sheet];
  } catch (e) {
    const s = document.createElement("style"); s.textContent = CSS; shadow.appendChild(s);
  }

  const root = document.createElement("div");
  root.innerHTML = `
    <button class="launcher" id="ax-launcher" title="ArenaX 에이전트 (드래그로 이동)">🤖</button>
    <div class="bubble" id="ax-bubble">
      <span class="bubble-text" id="ax-bubble-text"></span>
      <button class="bubble-close" id="ax-bubble-close" title="닫기">✕</button>
    </div>
    <div class="wrap">
      <div class="bar" id="ax-bar" hidden>
        <div class="head">
          <span class="title">🤖 ArenaX</span>
          <span class="task-counter" id="ax-counter">0/5 활성</span>
          <div class="head-btns">
            <button class="icon-btn" id="ax-gear" title="서버 설정">설정</button>
            <button class="min-btn"  id="ax-min"  title="질문창 닫기">▼ 접기</button>
            <button class="end-btn"  id="ax-end"  title="에이전트 종료">에이전트 종료</button>
          </div>
        </div>
        <div class="settings" id="ax-settings">
          <input id="ax-server" type="text" placeholder="https://arenax-4812.onrender.com" />
          <button id="ax-save">저장</button>
        </div>
        <div class="tasks-wrap" id="ax-tasks-wrap">
          <div class="tasks-inner" id="ax-tasks"></div>
        </div>
        <div class="resize-handle" id="ax-resize"></div>
        <div class="confirm" id="ax-confirm">
          <div class="confirm-msg" id="ax-confirm-msg"></div>
          <div class="confirm-btns">
            <button class="approve-btn" id="ax-approve">승인하고 진행</button>
            <button class="reject-btn"  id="ax-reject">취소</button>
          </div>
        </div>
        <div class="input-row">
          <textarea class="task-input" id="ax-input" rows="1"
            placeholder="이 화면에서 할 일을 지시하세요."></textarea>
          <button class="send-btn" id="ax-send">전송</button>
        </div>
      </div>
    </div>
  `;
  shadow.appendChild(root);

  const $          = id => shadow.getElementById(id);
  const launcher   = $("ax-launcher");
  const bubble     = $("ax-bubble");
  const bubbleText = $("ax-bubble-text");
  const bubbleClose= $("ax-bubble-close");
  const bar        = $("ax-bar");
  const counter    = $("ax-counter");
  const gearBtn    = $("ax-gear");
  const minBtn     = $("ax-min");
  const endBtn     = $("ax-end");
  const settings   = $("ax-settings");
  const serverInput= $("ax-server");
  const saveBtn    = $("ax-save");
  const resizeHandle=$("ax-resize");
  const tasksWrap  = $("ax-tasks-wrap");
  const tasksEl    = $("ax-tasks");
  const confirmBox = $("ax-confirm");
  const confirmMsg = $("ax-confirm-msg");
  const approveBtn = $("ax-approve");
  const rejectBtn  = $("ax-reject");
  const input      = $("ax-input");
  const sendBtnEl  = $("ax-send");

  document.documentElement.appendChild(host);

  const MAX_ACTIVE  = 5;
  let enabled       = false;
  let pendingConfirm= null;
  let launcherBottom= 96;
  let kbOffset = 0; // 모바일 키보드 높이 오프셋
  let tasksHeight   = 260;
  let bubbleTimer   = null;
  let prevNotifT    = 0;

  const STATUS = {
    running:   { label: "● 실행중",  cls: "running"   },
    paused:    { label: "⏸ 중단됨", cls: "paused"    },
    success:   { label: "✅ 완료",   cls: "success"   },
    error:     { label: "❌ 오류",   cls: "error"     },
    handoff:   { label: "🟡 전달",   cls: "handoff"   },
    cancelled: { label: "🛑 취소됨", cls: "cancelled" },
  };
  const ACTIVE_SET = new Set(["running", "paused"]);

  function esc(s) {
    return String(s).replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;");
  }

  // ── 표시 상태 ────────────────────────────────────────────────────────
  function render() { launcher.classList.toggle("show", enabled && bar.hidden); }
  function showBar(show) {
    bar.hidden = !show;
    render();
    if (show) input.focus();
    // 모든 탭에 동기화 — 한 탭에서 접으면 다른 탭도 같이 접힘
    try { chrome.storage.local.set({ barOpen: show }); } catch {}
  }
  function applyEnabled(v) { enabled = v; if (!v) bar.hidden = true; render(); }
  async function setEnabled(v) {
    try { await chrome.storage.local.set({ agentEnabled: v }); } catch {}
    applyEnabled(v);
  }
  function applyLauncherPos() {
    launcher.style.bottom = (launcherBottom + kbOffset) + "px";
    bubble.style.bottom   = (launcherBottom + 58 + kbOffset) + "px";
  }
  function applyTasksHeight() { tasksWrap.style.height = tasksHeight + "px"; }

  // ── 말풍선 ───────────────────────────────────────────────────────────
  const BUBBLE_CLS = { success:"success", error:"error", handoff:"handoff", cancelled:"cancelled" };
  function showBubble(text, kind) {
    bubbleText.textContent = text;
    bubble.className = "bubble show" + (BUBBLE_CLS[kind] ? " " + BUBBLE_CLS[kind] : "");
    clearTimeout(bubbleTimer);
    bubbleTimer = setTimeout(hideBubble, 3000);
  }
  function hideBubble() { clearTimeout(bubbleTimer); bubble.className = "bubble"; }
  bubbleClose.addEventListener("click", hideBubble);

  // ── 임무 렌더링 ──────────────────────────────────────────────────────
  function makeCard(task, archived) {
    const s = STATUS[task.status] || STATUS.error;
    const card = document.createElement("div");
    card.className = "task-card" + (archived ? " archived" : "");
    card.dataset.id     = task.id;
    card.dataset.status = task.status;

    const isActive = ACTIVE_SET.has(task.status);
    const latestStep = isActive && task.steps?.length ? task.steps[task.steps.length - 1] : null;
    const latestHtml = latestStep ? `<div class="task-latest">${esc(latestStep.text)}</div>` : "";
    const resultHtml = task.result ? `<div class="task-result ${esc(s.cls)}">${esc(task.result)}</div>` : "";

    let btnHtml = "";
    if (task.status === "running") {
      btnHtml = `<button class="tbtn pause-btn"  data-id="${esc(task.id)}">중단</button>
                 <button class="tbtn cancel-btn" data-id="${esc(task.id)}">취소</button>`;
    } else if (task.status === "paused") {
      btnHtml = `<button class="tbtn resume-btn" data-id="${esc(task.id)}">재개</button>
                 <button class="tbtn edit-btn"   data-id="${esc(task.id)}" data-text="${esc(task.text)}">수정</button>
                 <button class="tbtn cancel-btn" data-id="${esc(task.id)}">취소</button>`;
    } else {
      btnHtml = `<button class="tbtn edit-btn" data-id="${esc(task.id)}" data-text="${esc(task.text)}">수정</button>`;
    }
    btnHtml += `<button class="tbtn delete-btn" data-id="${esc(task.id)}">삭제</button>`;

    card.innerHTML = `
      <div class="task-head">
        <span class="task-text" title="${esc(task.text)}">${esc(task.text)}</span>
        <span class="task-badge ${esc(s.cls)}">${esc(s.label)}</span>
      </div>
      ${latestHtml}
      ${resultHtml}
      <div class="task-btns">${btnHtml}</div>
    `;
    return card;
  }

  function renderTasks(tasks) {
    const list = tasks || [];
    const active   = list.filter(t => ACTIVE_SET.has(t.status));
    const archived = list.filter(t => !ACTIVE_SET.has(t.status));

    counter.textContent = `${active.length}/${MAX_ACTIVE} 활성`;
    counter.classList.toggle("full", active.length >= MAX_ACTIVE);
    input.classList.toggle("full", active.length >= MAX_ACTIVE);
    input.placeholder = active.length >= MAX_ACTIVE
      ? `활성 임무가 ${MAX_ACTIVE}개입니다. 완료/취소 후 입력하세요.`
      : "이 화면에서 할 일을 지시하세요.";

    tasksEl.innerHTML = "";

    // ── 기록 먼저(위) — 위로 스크롤하면 볼 수 있음 ──
    if (archived.length) {
      const lbl = document.createElement("div");
      lbl.className = "section-label"; lbl.textContent = "기록";
      tasksEl.appendChild(lbl);
      archived.forEach(t => tasksEl.appendChild(makeCard(t, true)));
    }

    // ── 활성 임무 나중(아래) — 항상 화면에 보임 ──
    if (active.length) {
      const lbl = document.createElement("div");
      lbl.className = "section-label"; lbl.textContent = "활성 임무";
      tasksEl.appendChild(lbl);
      active.forEach(t => tasksEl.appendChild(makeCard(t, false)));
    }

    if (!active.length && !archived.length) {
      tasksEl.innerHTML = '<div class="empty">아직 임무가 없습니다. 아래에 지시사항을 입력하세요.</div>';
    }

    // 활성 임무가 아래 → 스크롤 하단으로 맞춰 활성 임무가 기본 노출
    tasksWrap.scrollTop = tasksWrap.scrollHeight;
  }

  // ── 임무 버튼 이벤트 (위임) ──────────────────────────────────────────
  tasksEl.addEventListener("click", async e => {
    const btn = e.target.closest("button[data-id]");
    if (!btn) return;
    const taskId = btn.dataset.id;
    if (btn.classList.contains("pause-btn"))
      { try { await chrome.runtime.sendMessage({ type: "PAUSE_TASK",  taskId }); } catch {} }
    else if (btn.classList.contains("resume-btn"))
      { try { await chrome.runtime.sendMessage({ type: "RESUME_TASK", taskId }); } catch {} }
    else if (btn.classList.contains("cancel-btn"))
      { try { await chrome.runtime.sendMessage({ type: "CANCEL_TASK", taskId }); } catch {} }
    else if (btn.classList.contains("delete-btn"))
      { try { await chrome.runtime.sendMessage({ type: "DELETE_TASK", taskId }); } catch {} }
    else if (btn.classList.contains("edit-btn")) {
      try {
        input.value = btn.dataset.text || "";
        input.style.height = "auto";
        input.style.height = Math.min(input.scrollHeight, 120) + "px";
        input.focus();
        input.setSelectionRange(input.value.length, input.value.length);
      } catch {}
    }
  });

  // ── 임무 제출 ────────────────────────────────────────────────────────
  function submitTask() {
    const task = input.value.trim();
    if (!task) return;
    input.value = ""; input.style.height = "auto"; input.focus();
    try {
      chrome.runtime.sendMessage({ type: "RUN_TASK", task }, () => void chrome.runtime.lastError);
    } catch (e) {
      // Extension context invalidated (확장 리로드 시) → 무시
    }
  }

  // ── 에이전트 종료 ────────────────────────────────────────────────────
  async function endAgent() {
    try { await chrome.runtime.sendMessage({ type: "STOP_TASK" }); } catch {}
    await setEnabled(false);
  }

  // ── 런처 드래그 (위아래) ─────────────────────────────────────────────
  let launcherDrag = null;
  launcher.addEventListener("pointerdown", e => {
    launcherDrag = { y: e.clientY, b: launcherBottom, moved: false };
    try { launcher.setPointerCapture(e.pointerId); } catch {}
    e.preventDefault();
  });
  launcher.addEventListener("pointermove", e => {
    if (!launcherDrag) return;
    const dy = launcherDrag.y - e.clientY;
    if (Math.abs(dy) > 4) launcherDrag.moved = true;
    launcherBottom = Math.max(12, Math.min(window.innerHeight - 64, launcherDrag.b + dy));
    applyLauncherPos();
  });
  function endLauncherDrag(e) {
    if (!launcherDrag) return;
    try { launcher.releasePointerCapture(e.pointerId); } catch {}
    const moved = launcherDrag.moved; launcherDrag = null;
    if (moved) { try { chrome.storage.local.set({ launcherBottom }); } catch {} }
    else showBar(true);
  }
  launcher.addEventListener("pointerup",     endLauncherDrag);
  launcher.addEventListener("pointercancel", () => { launcherDrag = null; });

  // ── 임무 목록 높이 조절 (드래그 핸들) ───────────────────────────────
  let resizing = null;
  resizeHandle.addEventListener("pointerdown", e => {
    resizing = { y: e.clientY, h: tasksHeight };
    try { resizeHandle.setPointerCapture(e.pointerId); } catch {}
    e.preventDefault();
  });
  resizeHandle.addEventListener("pointermove", e => {
    if (!resizing) return;
    // 핸들이 tasks-wrap 아래에 있으므로: 위로 드래그 = 줄이기, 아래로 드래그 = 늘리기
    const dy = e.clientY - resizing.y;
    tasksHeight = Math.max(80, Math.min(Math.round(window.innerHeight * 0.6), resizing.h + dy));
    applyTasksHeight();
  });
  function endResize(e) {
    if (!resizing) return;
    try { resizeHandle.releasePointerCapture(e.pointerId); } catch {}
    resizing = null;
    try { chrome.storage.local.set({ tasksHeight }); } catch {}
  }
  resizeHandle.addEventListener("pointerup",     endResize);
  resizeHandle.addEventListener("pointercancel", () => { resizing = null; });

  // ── 헤더 버튼 ────────────────────────────────────────────────────────
  minBtn.addEventListener("click", () => showBar(false));
  endBtn.addEventListener("click", endAgent);
  gearBtn.addEventListener("click", () => settings.classList.toggle("open"));

  saveBtn.addEventListener("click", async () => {
    try {
      const res = await chrome.runtime.sendMessage({ type: "SET_SERVER_URL", serverUrl: serverInput.value });
      if (res?.serverUrl) serverInput.value = res.serverUrl;
      saveBtn.textContent = "저장됨 ✓";
      setTimeout(() => (saveBtn.textContent = "저장"), 1500);
    } catch { saveBtn.textContent = "실패"; setTimeout(() => (saveBtn.textContent = "저장"), 1500); }
  });

  sendBtnEl.addEventListener("click", submitTask);
  input.addEventListener("keydown", e => { if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); submitTask(); } });
  input.addEventListener("input", () => { input.style.height = "auto"; input.style.height = Math.min(input.scrollHeight, 120) + "px"; });

  // ── 확인 요청 ────────────────────────────────────────────────────────
  function resolveConfirm(approved) {
    confirmBox.classList.remove("open");
    if (pendingConfirm) { try { pendingConfirm({ approved }); } catch {} pendingConfirm = null; }
  }
  approveBtn.addEventListener("click", () => resolveConfirm(true));
  rejectBtn.addEventListener("click",  () => resolveConfirm(false));

  chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
    if (msg.type === "AGENT_CONFIRM") {
      showBar(true);
      confirmMsg.textContent =
        "[확인 필요] " + (msg.message || "중요한 동작") +
        "\n동작: " + (msg.action || "") + "\n이유: " + (msg.reasoning || "");
      confirmBox.classList.add("open");
      pendingConfirm = sendResponse;
      return true;
    }
  });

  // ── 사이트 브리지 ────────────────────────────────────────────────────
  window.addEventListener("message", event => {
    if (event.source !== window) return;
    const d = event.data;
    if (!d || d.__arenax !== "agent") return;
    if (d.type === "PING") window.postMessage({ __arenax: "agent", type: "READY" }, "*");
    else if (d.type === "OPEN") { window.postMessage({ __arenax: "agent", type: "READY" }, "*"); setEnabled(true); showBar(true); }
    else if (d.type === "CLOSE") endAgent();
  });
  window.postMessage({ __arenax: "agent", type: "READY" }, "*");

  // ── storage.onChanged ────────────────────────────────────────────────
  chrome.storage.onChanged.addListener((changes, area) => {
    if (area !== "local") return;
    if (changes.agentEnabled) applyEnabled(!!changes.agentEnabled.newValue);
    if (changes.agentTasks)   renderTasks(changes.agentTasks.newValue || []);
    if (changes.launcherBottom && typeof changes.launcherBottom.newValue === "number") {
      launcherBottom = changes.launcherBottom.newValue; applyLauncherPos();
    }
    if (changes.tasksHeight && typeof changes.tasksHeight.newValue === "number") {
      tasksHeight = changes.tasksHeight.newValue; applyTasksHeight();
    }
    if (changes.latestNotification) {
      const n = changes.latestNotification.newValue;
      if (n && n.t && n.t !== prevNotifT) {
        prevNotifT = n.t;
        if (bar.hidden) showBubble(n.text, n.kind);
      }
    }
    // 탭 간 바 열기/닫기 동기화
    if (changes.barOpen !== undefined && enabled) {
      const open = !!changes.barOpen.newValue;
      bar.hidden = !open;
      render();
    }
  });

  // ── 모바일 키보드 올라올 때 바/런처 위로 이동 ─────────────────────────
  function updateKbOffset() {
    if (!window.visualViewport) return;
    const vv = window.visualViewport;
    const newOffset = Math.max(0, window.innerHeight - vv.height - vv.offsetTop);
    if (newOffset === kbOffset) return;
    kbOffset = newOffset;
    host.style.bottom = kbOffset + "px";
    applyLauncherPos();
  }
  if (window.visualViewport) {
    window.visualViewport.addEventListener("resize", updateKbOffset);
    window.visualViewport.addEventListener("scroll", updateKbOffset);
  }

  // ── 초기화 ───────────────────────────────────────────────────────────
  chrome.storage.local
    .get(["agentEnabled", "serverUrl", "agentTasks", "launcherBottom", "tasksHeight", "barOpen"])
    .then(s => {
      if (s.serverUrl) serverInput.value = s.serverUrl;
      if (typeof s.launcherBottom === "number") launcherBottom = s.launcherBottom;
      if (typeof s.tasksHeight    === "number") tasksHeight    = s.tasksHeight;
      applyLauncherPos();
      applyTasksHeight();
      renderTasks(s.agentTasks || []);
      applyEnabled(!!s.agentEnabled);
      // barOpen: 에이전트가 켜져 있고 바가 열린 상태였으면 복원
      if (!!s.agentEnabled && s.barOpen === true) { bar.hidden = false; render(); }
    })
    .catch(() => {});
})();
